Mock Twitter API with ExpressJS and JSON data backend.

Author: Luke Fronheiser
Date: 27 Feb 2022

Technologies used:
- HTML
- ExpressJS
- Ajax
- Javascript



This mock API can be downloaded and opened into a VS Code IDE.
Open a terminal and navigate to the root download folder.
Then run the command

" node app.js "

and the app will be visible at the directory

"http://localhost:3000/"

